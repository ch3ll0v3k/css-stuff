<!DOCTYPE html>
<html class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Zakenkantoor Matthijs</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="icon" type="image/png" href="/favicon.png">

    <!-- [CSS] -->
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/main.style.css">

    <link rel="stylesheet" href="/css/last.mod.style.main.css">
    <link rel="stylesheet" href="/css/last.mod.style.blokken.css">
    <link rel="stylesheet" href="/css/last.mod.style.content.css">
    <link rel="stylesheet" href="/css/last.mod.style.contacts.css">
    <link rel="stylesheet" href="/css/last.mod.style.social.css">

    <!-- [JS] -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://code.jquery.com/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.1.min.js"><\/script>')</script>
    <script src="js/main.js"></script>

    <!--[if lt IE 9]>
        <script src="http:////html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <script>window.html5 || document.write('<script src="js/vendor/html5shiv.js"><\/script>')</script>
    <![endif]-->

    <script type="text/javascript">
        
        function byId(id){ return document.getElementById(id); }

        var ONCE = true;
        window.addEventListener('resize', function(evt){ byId('debug-box').innerHTML = '<- '+evt.target.innerWidth+'px ->'; });

    </script>
    
</head>
<body>

    <!-- ########################################################################### -->
    <div id="debug-box"> </div> 

    <!-- ########################################################################### -->
    <header>
        <!-- =================================== -->
        <section class="row topbar">
            <div class="grid">

                <a href="#" class="topContact">
                    <i class="fa fa-map-marker" aria-hidden="true"></i> Neerstraat 6 - 9570 Lierde
                </a>

                <a href="#" class="topContact">
                    <i class="fa fa-phone-square" aria-hidden="true"></i> 055/42.67.81
                </a>
                
                <a href="#" class="topContact">
                    <i class="fa fa-envelope" aria-hidden="true"></i> info@matthijs-zakenkantoor.be
                </a>

            </div>
        </section>
        
        <!-- =================================== -->
        <section class="row mainMenu">
            <div class="grid">

                <!-- ******************* logo ************************ -->
                <div id="main-site-log">
                    <a href="/"><img src="images/logo.png"></a>
                </div>
                <!-- ******************* menus ************************ -->
                <div id="menu-top-no-adapt">
                    <nav class="mainNav">
                        <ul>

                            <!--
                            <li class="active"><a href="/">Home</a></li>
                            -->
                            <li><a href="/">Home</a></li>
                            <li><a href="/bank">Bank</a></li>
                            <li><a href="/kantoor">Kantoor</a></li>
                            <li><a href="/diensten">Onze diensten</a></li>
                            <li><a href="/info">Nuttige info</a></li>
                            <li><a href="/contact">Contact</a></li>

                        </ul>
                    </nav>
        
                </div>  

                <div id="menu-top-adapt">
                    <div id="menu-top-adapt-icon-btn"> 
                        <div id="menu-top-adapt-icon-btn-lable">Navigatie</div>
                        <div id="menu-top-adapt-float-box">
                            <a href="/"><div class="menu-top-adapt-float-item">Home</div></a>
                            <a href="/bank"><div class="menu-top-adapt-float-item">Bank</div></a>
                            <a href="/kantoor"><div class="menu-top-adapt-float-item">Kantoor</div></a>
                            <a href="/diensten"><div class="menu-top-adapt-float-item">Onze diensten</div></a>
                            <a href="/info"><div class="menu-top-adapt-float-item">Nuttige info</div></a>
                            <a href="/contact"><div class="menu-top-adapt-float-item">Contact</div></a>
                        </div>
                    </div>
                </div>  

                <!--    
                {option:navigationTop}
                <div class="mainNavFloatBar" onclick="mainNavFloatMenuCtrl()"> </div>
                <div class="mainNavFloatContent" id="mainNavFloatContent">

                    {iteration:navigation}

                        {option:navigation.subs}
                            {iteration:navigation.subs}
                                <div class="mainNavFloatContentItem" style="margin-left: 10px; border-left: solid 3px #F00;"><a href="{$navigation.subs.url}">{$navigation.subs.title}</a></div>
                            {/iteration:navigation.subs}
                        {/option:navigation.subs}

                        {option:!navigation.subs}
                            <div class="mainNavFloatContentItem"><a href="{$navigation.url}">{$navigation.title}</a></div>
                        {/option:!navigation.subs}

                    {/iteration:navigation}

                </div>              
                {/option:navigationTop}
                -->

                <!-- ******************* /menus ************************ -->
            </div>
        </section>
        <!-- =================================== -->
        
        <!-- =================================== -->
        <!--
        <section class="row mainSlider">
        <div class="grid">
            <div class="slider-pro" id="my-slider">
            <div class="sp-slides">

                <div class="sp-slide">
                <img class="sp-image" src="images/slider1.jpg"/>
                <div class="sp-layer sliderWrapper" data-horizontal="60%" data-vertical="50"
                    data-show-transition="left" data-show-delay="900">
                    <h3 class="sliderTitle">
                    Beleggingen - Leningen - Verzekeringen
                    </h3>
                    <div class="sliderContent"
                        data-horizontal="60%" data-vertical="140"
                        data-show-transition="right" data-show-delay="950">
                    Wij zorgen steeds voor de meest veilige en rendabele oplossing voor u
                    </div>
                    <a href="#" class="sliderLink"
                        data-horizontal="60%" data-vertical="250"
                        data-show-transition="left" data-show-delay="1000">
                    Lees verder
                    </a>
                </div>
                </div>
            
                <div class="sp-slide">
                <img class="sp-image" src="images/slider2.jpg"/>
                <div class="sp-layer sliderWrapper" data-horizontal="60%" data-vertical="50"
                    data-show-transition="left" data-show-delay="900">
                    <h3 class="sliderTitle">
                    Nuttige info voor u
                    </h3>
                    <div class="sliderContent"
                        data-horizontal="60%" data-vertical="140"
                        data-show-transition="right" data-show-delay="950">
                    Wij houden u steeds op de hoogte van de voor u relevante evoluties
                    </div>
                    <a href="#" class="sliderLink"
                        data-horizontal="60%" data-vertical="250"
                        data-show-transition="left" data-show-delay="1000">
                    Lees verder
                    </a>
                </div>
                </div>
        
            </div>
            </div>
        </div>
        </section> -->
    </header>
    <!-- ########################################################################### -->