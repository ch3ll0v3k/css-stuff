<?php include($_SERVER['DOCUMENT_ROOT'].'/header.php'); ?> 

    <!-- ########################################################################### -->
    <section class="row mainContent">

        <!-- :::::::::::::::::::::::::::::: -->
        <div class="blokken-wrapper">
            
            <div class="blok-item-wrapper">
                <div class="blok-item-title">
                    <div class="blok-item-title-icon"></div>
                    This Is Blokken Title
                </div>

                <div class="blok-item-body">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </div>

                <div class="blok-item-footer">
                    Text <a class="blok-item-footer-link" href="#">Lees meer</a>
                </div>
            </div>

            <div class="blok-item-wrapper">
                <div class="blok-item-title">
                    <div class="blok-item-title-icon"></div>
                    This Is Blokken Title
                </div>

                <div class="blok-item-body">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </div>

                <div class="blok-item-footer">
                    <a class="blok-item-footer-link" href="#">Lees meer</a>
                </div>
            </div>

        </div>

        <!-- :::::::::::::::::::::::::::::: -->
        <div class="content-wrapper">
            
            <div class="content-item-wrapper">
                <div class="content-item-title">RECORD BANK - LIERDE: Wat kunnen wij voor u doen</div>

                <div class="content-item-body">

                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor 
                    ris nisi ut aliquip ex ea commo m ad minim veniam, quis nostrud 
                    incididunt ut labore et dolore magna aliqua. Ut eni quis nostrud 
                    irure dolor in reprehenderit in voluptate velit esse cillum dolore eu 
                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud 
                    <img class="content-item-body-img" src="images/2.JPG">
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu 
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor 
                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud 
                    exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu 
                    fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, 
                    sunt in culpa qui officia deserunt mollit anim id est laborum.
                    <img class="content-item-body-img" style="float: right !important;" src="images/3.JPG">
                    Duis aute irure dolor in  in voluptate velit esse cillum dolore eu 
                    incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud 
                    ris nisi ut aliquip ex ea commo m ad minim veniam, quis nostrud 
                    incididunt ut labore et dolore magna aliqua. Ut eni quis nostrud 
                    irure dolor in reprehenderit in voluptate velit esse cillum dolore eu 
                    exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                    Duis aute irure dolor in reprehenderit in voluptate dolore eu 
                    sunt in culpa qui officia deserunt mollit anim id est laborum.
                    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu 
                    exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 

                </div>

                <div class="content-item-footer">
                    <!--
                    <a class="content-item-footer-link" href="#">Lees meer</a>
                    -->
                </div>

            </div>

        </div>
        <!-- :::::::::::::::::::::::::::::: -->

    </section>
    <!-- ########################################################################### -->

<?php include($_SERVER['DOCUMENT_ROOT'].'/footer.php'); ?> 
