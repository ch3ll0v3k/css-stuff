<?php include($_SERVER['DOCUMENT_ROOT'].'/header.php'); ?> 

    <!-- ########################################################################### -->
    <section class="row mainContent">

        <!-- :::::::::::::::::::::::::::::: -->
        <div class="contacts-wrapper">
            
            <form class="contacts-form" action="" method="post">

                <div class="contacts-form-title">Contacteer ons - Informeer voor hulp en advies ?</div>

                <div class="contacts-form-row">
                    <div class="contacts-form-input-lable">Voornaam:</div>
                    <input type="text" name="name" class="contacts-form-input"/>
                </div>

                <div class="contacts-form-row">
                    <div class="contacts-form-input-lable">Achternaam:</div>
                    <input type="text" name="f_name" class="contacts-form-input" />
                </div>

                <div class="contacts-form-row">
                    <div class="contacts-form-input-lable">Email:</div>
                    <input type="text" name="name" class="contacts-form-input" placeholder="email@mail.com" />
                </div>

                <div class="contacts-form-row">
                    <div class="contacts-form-input-lable">Boodschap:</div>
                    <textarea name="name" class="contacts-form-textarea"> This is massage body ...</textarea>
                </div>

                <div class="contacts-form-row">
                    <input type="submit" name="name" value="Clear" class="contacts-form-btn"/>
                    <input type="submit" name="name" value="Verzenden" class="contacts-form-btn"/>
                </div>

            </form>

        </div>
        <!-- :::::::::::::::::::::::::::::: -->

        <div class="blokken-wrapper">
            
            <div class="blok-item-wrapper">
                <div class="blok-item-title">This Is Blokken Title</div>

                <div class="blok-item-body">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </div>

                <div class="blok-item-footer">
                    Text <a class="blok-item-footer-link" href="#">Lees meer</a>
                </div>
            </div>

            <div class="blok-item-wrapper">
                <div class="blok-item-title">This Is Blokken Title</div>

                <div class="blok-item-body">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                </div>

                <div class="blok-item-footer">
                    <a class="blok-item-footer-link" href="#">Lees meer</a>
                </div>
            </div>

        </div>
        <!-- :::::::::::::::::::::::::::::: -->


    </section>
    <!-- ########################################################################### -->

<?php include($_SERVER['DOCUMENT_ROOT'].'/footer.php'); ?> 
