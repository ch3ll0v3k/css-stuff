    <!-- ########################################################################### -->
    <footer class="">
        <article class="upperFooter">
            <div class="grid" style="text-align: center;">
                <div class="before-footer-address-info-item"><i class="fa fa-map-marker" aria-hidden="true"> </i> Neerstraat 6 - 9570 Lierde</div>
                <div class="before-footer-address-info-item"><i class="fa fa-phone-square" aria-hidden="true"> </i> 055 42 67 81</div>
                <div class="before-footer-address-info-item"><i class="fa fa-envelope" aria-hidden="true"> </i> matthijs.zakenkantoor@recordbank.be</div>
            </div>
        </article>
        <!-- :::::::::::::::::::::::::::: -->

        <!-- :::::::::::::::::::::::::::: -->
        <article class="row bottomFooter" style="text-align: center;">
            <div class="grid">
            
                <div class="footer-visit-hours-wrapper">
                    <div class="footer-visit-hours-wrapper-m-day">Maandag</div>
                    <div class="footer-visit-hours-wrapper-hours">09:00 - 12:00</div>
                    <div class="footer-visit-hours-wrapper-hours">Op afspraak</div>
                </div>
                
                <div class="footer-visit-hours-wrapper">
                    <div class="footer-visit-hours-wrapper-m-day">Dinsdag</div>
                    <div class="footer-visit-hours-wrapper-hours">16:30 - 19:00</div>
                    <div class="footer-visit-hours-wrapper-hours">Gesloten</div>
                </div>
                
                <div class="footer-visit-hours-wrapper">
                    <div class="footer-visit-hours-wrapper-m-day">Woensdag</div>
                    <div class="footer-visit-hours-wrapper-hours">09:00 - 12:00</div>
                    <div class="footer-visit-hours-wrapper-hours">Op afspraak</div>
                </div>
                
                <div class="footer-visit-hours-wrapper">
                    <div class="footer-visit-hours-wrapper-m-day">Donderdag</div>
                    <div class="footer-visit-hours-wrapper-hours">09:00 - 12:00</div>
                    <div class="footer-visit-hours-wrapper-hours">16:30 - 19:00</div>
                </div>
                
                <div class="footer-visit-hours-wrapper">
                    <div class="footer-visit-hours-wrapper-m-day">Vrijdag</div>
                    <div class="footer-visit-hours-wrapper-hours">09:00 - 12:00</div>
                    <div class="footer-visit-hours-wrapper-hours">Op Afspraak</div>
                </div>

                <div class="footer-visit-hours-wrapper">
                    <div class="footer-visit-hours-wrapper-m-day wrapper-m-day-zat-zon">Zaterdag</div>
                    <div class="footer-visit-hours-wrapper-hours">10:00 - 12:00</div>
                    <div class="footer-visit-hours-wrapper-hours">Gesloten</div>
                </div>
                
                <div class="footer-visit-hours-wrapper">
                    <div class="footer-visit-hours-wrapper-m-day wrapper-m-day-zat-zon">Zondag</div>
                    <div class="footer-visit-hours-wrapper-hours">Gesloten</div>
                    <div class="footer-visit-hours-wrapper-hours">Gesloten</div>
                </div>

            </div>

        </article>

        <article class="row afterBottomFooter" style="text-align: center;">

            <a href="_FB_"> <div class="soc_icon facebook"></div> </a>
            <a href="_TW_"> <div class="soc_icon twitter"></div> </a>
            <a href="_IN_"> <div class="soc_icon instagram"></div> </a>
            <a href="_LK_"> <div class="soc_icon linked"></div> </a>
            <a href="_YT_"> <div class="soc_icon youtube"></div> </a>
            <a href="_GP_"> <div class="soc_icon googlepluss"></div> </a>
            <a href="_PI_"> <div class="soc_icon pinterest"></div> </a> 

        </article>
        <!-- :::::::::::::::::::::::::::: -->
        <article class="row bottomFooter" style="text-align: center;">

            <div id="company-footer-info-block">

                &copy; 2016 
                | Powered by <a class="company-footer-info-link" href="http://www.my-websitebuilder.com/">my-websitebuilder.com</a> 
                | SEO &amp; SEA by <a class="company-footer-info-link" href="http://opti-seo.com/">Opti-Seo.com</a>

            </div>

        </article>

    </footer>
    <!-- =================================== -->

    <!-- Google Analytics: change UA-XXXXX-X to be your site's ID.
    <script>
        (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
        function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
        e=o.createElement(i);r=o.getElementsByTagName(i)[0];
        e.src='//www.google-analytics.com/analytics.js';
        r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
        ga('create','UA-XXXXX-X');ga('send','pageview');
    </script>
    
    -->
    <!-- ########################################################################### -->

</body>
</html>
