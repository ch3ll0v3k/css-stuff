<?php include('header.php'); ?> 

    <!-- ########################################################################### -->
    <section class="row mainContent">
        <div class="intro-blocks-wrapper">

            <!-- *************************** -->
            <a href="/bank">
                <div class="intro-block-item-wrapper">
                    <div class="intro-block-item-abs-icon bank-icon"></div>
                    <div class="intro-block-item-title">Uw bank</div>
                    <div class="intro-block-item-slogan">RECORD BANK - LIERDE</div>
                    <div class="intro-block-item-logo">
                        <img src="images/uw_bank.png" />
                    </div>
                </div>
            </a>

            <!-- *************************** -->
            <a href="/kantoor">
                <div class="intro-block-item-wrapper">
                    <div class="intro-block-item-abs-icon office-icon"></div>
                    <div class="intro-block-item-title"> Uw zakenkantoor</div>
                    <div class="intro-block-item-slogan">ZAKENKANTOOR MATTHIJS</div>
                    <div class="intro-block-item-logo">
                        <img src="images/uw_zakenkantoor.png" />
                    </div>
                </div>
            </a>
            <!-- *************************** -->

        </div>

    </section>
    <!-- ########################################################################### -->

<?php include('footer.php'); ?> 